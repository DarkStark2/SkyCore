package com.skyspace.skycore.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * MiniMessage-based text helper.
 * You’re already using TextUtils.get() in SkyHoppers, so this matches that pattern.
 */
public class TextUtils {

    private static final MiniMessage mm = MiniMessage.miniMessage();
    private static final TextUtils instance = new TextUtils();

    public static TextUtils get() {
        return instance;
    }

    public Component mm(String text) {
        return mm.deserialize(text == null ? "" : text);
    }

    public String strip(String text) {
        return mm.stripTags(text == null ? "" : text);
    }

    public void send(CommandSender sender, String message) {
        sender.sendMessage(mm.deserialize(message == null ? "" : message));
    }

    public void send(Player player, String message) {
        player.sendMessage(mm.deserialize(message == null ? "" : message));
    }

    public void sendPrefixed(Player player, String prefix, String message) {
        player.sendMessage(mm.deserialize(
                (prefix == null ? "" : prefix + " ") +
                        (message == null ? "" : message)
        ));
    }

    public void sendPrefixed(CommandSender sender, String prefix, String message) {
        sender.sendMessage(mm.deserialize(
                (prefix == null ? "" : prefix + " ") +
                        (message == null ? "" : message)
        ));
    }
}
